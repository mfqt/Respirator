# -*- coding: utf-8 -*-
# @Time    : 2020/5/22 0:52
# @Author  : Mat
# @Email   : mat_wu@163.com
# @File    : executor_test.py
# @Software: PyCharm

import tkinter as tk
import communicator
import appWidget
import queue

def r_a():
    _r = tk.Tk()
    _r.geometry("1000x600+200+200")

    q_t_dp = queue.Queue()
    se = communicator.Serial_c(q_t_dp)
    if se.config_serial():
        for mess in se.start_serial_communication():
            if not mess:
                return
            print(mess)

    so = communicator.Socket_c(q_t_dp)
    if so.config_socket():
        for mess in so.start_socket_communication():
            if not mess:
                return
            print(mess)

    exe = appWidget.Executor(_r, (1000, 600, 200, 200), so, se.writer, q_t_dp)
    exe.run()

    _r.mainloop()



if __name__ == '__main__':
    r_a()
